package com.sistema.biblioteca.Util;

import com.sistema.biblioteca.Dto.Request.UsuarioRequestDTO;
import com.sistema.biblioteca.Dto.Response.UsuarioResponseDTO;
import com.sistema.biblioteca.Entities.Usuario;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class UsuarioMapper {
    // Mapper para converter entre DTOs e a entidade Usuario

    public Usuario toUsuario(UsuarioRequestDTO usuarioDTO) {
        // Método para converter um DTO de Usuario em uma entidade Usuario
        return Usuario.builder()
                .nome(usuarioDTO.getNome())
                .email(usuarioDTO.getEmail())
                .telefone(usuarioDTO.getTelefone())
                .endereco(usuarioDTO.getEndereco())
                .build();
    }

    public UsuarioResponseDTO toUsuarioDTO(Usuario usuario) {
        // Método para converter uma entidade Usuario em um DTO de Usuario
        return new UsuarioResponseDTO(usuario);
    }

    public List<UsuarioResponseDTO> toUsuarioDTOList(List<Usuario> usuarioList) {
        // Método para converter uma lista de entidades Usuario em uma lista de DTOs de Usuario
        return usuarioList.stream().map(UsuarioResponseDTO::new).collect(Collectors.toList());
    }

    public void updateUsuarioData(Usuario usuario, UsuarioRequestDTO usuarioDTO) {
        // Método para atualizar os dados de um Usuario com base nas informações fornecidas no DTO
        usuario.setNome(usuarioDTO.getNome());
        usuario.setEmail(usuarioDTO.getEmail());
        usuario.setTelefone(usuarioDTO.getTelefone());
        usuario.setEndereco(usuarioDTO.getEndereco());
    }
}
