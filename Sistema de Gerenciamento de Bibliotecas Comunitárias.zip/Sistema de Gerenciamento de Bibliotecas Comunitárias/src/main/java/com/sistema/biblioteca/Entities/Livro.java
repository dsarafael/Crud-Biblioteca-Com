package com.sistema.biblioteca.Entities;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity // Indica que a classe é uma entidade JPA
@Table(name = "tb_livro") // Mapeia a classe para a tabela "tb_livro" no banco de dados
@NoArgsConstructor // Gera um construtor sem argumentos
@Getter // Gera métodos getter
@Setter // Gera métodos setter
public class Livro {
    
    @Id // Indica que o campo é uma chave primária
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Gera automaticamente o valor do campo
    @Column(name = "id", nullable = false, unique = true) // Mapeia a coluna "id" no banco de dados
    @Setter(AccessLevel.NONE) // Impede a geração do setter para o campo "id"
    private Long id;

    @Column(name = "titulo", nullable = false) // Mapeia a coluna "titulo" no banco de dados
    private String titulo;

    @Column(name = "categoria", nullable = false) // Mapeia a coluna "categoria" no banco de dados
    private String categoria;

    @Column(name = "ano_publicacao", nullable = false) // Mapeia a coluna "ano_publicacao" no banco de dados
    private int ano_publicacao;

    @Column(name = "status", nullable = false) // Mapeia a coluna "status" no banco de dados
    private String status;

    @Column(name = "data_aquisicao", nullable = false) // Mapeia a coluna "data_aquisicao" no banco de dados
    private Date data_aquisicao;

    @Column(name = "autor", nullable = false) // Mapeia a coluna "autor" no banco de dados
    private String autor;

    @Builder // Gera um padrão Builder para a classe
    public Livro(String titulo, String categoria, int ano_publicacao, String status, Date data_aquisicao, String autor) {
        this.titulo = titulo;
        this.categoria = categoria;
        this.ano_publicacao = ano_publicacao;
        this.status = status;
        this.data_aquisicao = data_aquisicao;
        this.autor = autor;
    }
}
