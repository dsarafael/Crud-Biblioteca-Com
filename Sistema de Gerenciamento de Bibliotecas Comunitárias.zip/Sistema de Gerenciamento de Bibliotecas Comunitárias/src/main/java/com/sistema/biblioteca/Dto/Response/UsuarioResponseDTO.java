package com.sistema.biblioteca.Dto.Response;

import com.sistema.biblioteca.Entities.Usuario;
import lombok.Getter;

@Getter
public class UsuarioResponseDTO {
    // DTO para enviar dados de resposta de usuário

    private Long id;            // ID do usuário
    private String nome;        // Nome do usuário
    private String email;       // E-mail do usuário
    private String telefone;    // Telefone do usuário
    private String endereco;    // Endereço do usuário

    // Construtor que recebe um objeto de usuário e popula os campos do DTO
    public UsuarioResponseDTO(Usuario usuario) {
        this.id = usuario.getId();
        this.nome = usuario.getNome();
        this.email = usuario.getEmail();
        this.telefone = usuario.getTelefone();
        this.endereco = usuario.getEndereco();
    }
}
