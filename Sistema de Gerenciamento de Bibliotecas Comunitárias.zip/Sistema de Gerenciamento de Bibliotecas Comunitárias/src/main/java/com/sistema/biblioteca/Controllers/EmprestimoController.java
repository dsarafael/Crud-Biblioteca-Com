package com.sistema.biblioteca.Controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import com.sistema.biblioteca.Dto.Request.EmprestimoRequestDTO;
import com.sistema.biblioteca.Dto.Response.EmprestimoResponseDTO;
import com.sistema.biblioteca.service.EmprestimoService;

import lombok.RequiredArgsConstructor;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping(value = "/emprestimo")
@RequiredArgsConstructor
public class EmprestimoController {
    // Controlador para operações relacionadas a empréstimos

    private final EmprestimoService emprestimoService;

    // Endpoint para buscar um empréstimo por ID
    @GetMapping(value = "/{id}")
    public ResponseEntity<EmprestimoResponseDTO> findById(@PathVariable(name = "id") Long id) {
        return ResponseEntity.ok().body(emprestimoService.findById(id));
    }

    // Endpoint para buscar todos os empréstimos
    @GetMapping
    public ResponseEntity<List<EmprestimoResponseDTO>> findAll() {
        return ResponseEntity.ok().body(emprestimoService.findAll());
    }

    // Endpoint para registrar um novo empréstimo
    @PostMapping
    public ResponseEntity<EmprestimoResponseDTO> register(@RequestBody EmprestimoRequestDTO emprestimoRequestDTO, UriComponentsBuilder uriBuilder) {
        EmprestimoResponseDTO emprestimoResponseDTO = emprestimoService.register(emprestimoRequestDTO);
        URI uri = uriBuilder.path("/emprestimo/{id}").buildAndExpand(emprestimoResponseDTO.getId()).toUri();
        return ResponseEntity.created(uri).body(emprestimoResponseDTO);
    }

    // Endpoint para atualizar um empréstimo existente
    @PutMapping(value = "/{id}")
    public ResponseEntity<EmprestimoResponseDTO> update(@RequestBody EmprestimoRequestDTO emprestimoDTO, @PathVariable(name = "id") Long id) {
        return ResponseEntity.ok().body(emprestimoService.update(id, emprestimoDTO));
    }

    // Endpoint para excluir um empréstimo por ID
    @DeleteMapping(value = "/{id}")
    public ResponseEntity<String> delete(@PathVariable(value = "id") Long id) {
        return ResponseEntity.ok().body(emprestimoService.delete(id));
    }
}
