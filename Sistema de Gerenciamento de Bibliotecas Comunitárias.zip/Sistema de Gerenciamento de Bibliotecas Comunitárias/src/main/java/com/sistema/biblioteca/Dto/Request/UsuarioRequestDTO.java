package com.sistema.biblioteca.Dto.Request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UsuarioRequestDTO {
    // DTO para receber dados de requisição de usuário

    private String nome;        // Nome do usuário
    private String email;       // E-mail do usuário
    private String telefone;    // Telefone do usuário
    private String endereco;    // Endereço do usuário
}
