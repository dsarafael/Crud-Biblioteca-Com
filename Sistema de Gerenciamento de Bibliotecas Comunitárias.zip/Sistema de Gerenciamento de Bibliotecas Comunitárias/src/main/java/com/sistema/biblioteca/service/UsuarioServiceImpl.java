package com.sistema.biblioteca.service;

import com.sistema.biblioteca.Dto.Request.UsuarioRequestDTO;
import com.sistema.biblioteca.Dto.Response.UsuarioResponseDTO;
import com.sistema.biblioteca.Entities.Usuario;
import com.sistema.biblioteca.Repository.UsuarioRepository;
import com.sistema.biblioteca.Util.UsuarioMapper;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UsuarioServiceImpl implements UsuarioService {
    // Implementação da interface UsuarioService

    private final UsuarioRepository usuarioRepository; // Repositório para acessar os dados do usuário
    private final UsuarioMapper usuarioMapper; // Mapper para converter entre DTOs e entidades

    @Override
    public UsuarioResponseDTO findById(Long id) {
        // Método para encontrar um usuário pelo ID e retornar as informações convertidas em DTO
        return usuarioMapper.toUsuarioDTO(returnUsuario(id));
    }

    @Override
    public List<UsuarioResponseDTO> findAll() {
        // Método para encontrar todos os usuários e retornar uma lista das informações convertidas em DTO
        return usuarioMapper.toUsuarioDTOList(usuarioRepository.findAll());
    }

    @Override
    public UsuarioResponseDTO register(UsuarioRequestDTO usuarioDTO) {
        // Método para registrar um novo usuário com base nas informações fornecidas no DTO
        Usuario usuario = usuarioMapper.toUsuario(usuarioDTO);
        return usuarioMapper.toUsuarioDTO(usuarioRepository.save(usuario));
    }

    @Override
    public UsuarioResponseDTO update(Long id, UsuarioRequestDTO usuarioDTO) {
        // Método para atualizar as informações de um usuário existente com base no ID fornecido
        Usuario usuario = returnUsuario(id);
        usuarioMapper.updateUsuarioData(usuario, usuarioDTO);
        return usuarioMapper.toUsuarioDTO(usuarioRepository.save(usuario));
    }

    @Override
    public String delete(Long id) {
        // Método para deletar um usuário com base no ID fornecido e retornar uma mensagem indicando a exclusão
        usuarioRepository.deleteById(id);
        return "Usuário id: " + id + " deleted";
    }

    private Usuario returnUsuario(Long id) {
        // Método auxiliar para encontrar um usuário pelo ID
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado no banco de dados"));
    }
}
