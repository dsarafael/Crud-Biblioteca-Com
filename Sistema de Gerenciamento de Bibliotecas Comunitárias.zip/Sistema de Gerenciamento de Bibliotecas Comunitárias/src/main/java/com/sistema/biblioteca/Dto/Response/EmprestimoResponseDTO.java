package com.sistema.biblioteca.Dto.Response;

import com.sistema.biblioteca.Entities.Emprestimo;
import lombok.Getter;

import java.util.Date;

@Getter
public class EmprestimoResponseDTO {
    // DTO para enviar dados de resposta de empréstimo

    private Long id;                // ID do empréstimo
    private Date dataEmprestimo;    // Data de empréstimo
    private Date dataDevolucao;     // Data de devolução
    private String status;          // Status do empréstimo
    private Long livroId;           // ID do livro relacionado ao empréstimo
    private Long usuarioId;         // ID do usuário relacionado ao empréstimo

    // Construtor que recebe um objeto de empréstimo e popula os campos do DTO
    public EmprestimoResponseDTO(Emprestimo emprestimo) {
        this.id = emprestimo.getId();
        this.dataEmprestimo = emprestimo.getDataEmprestimo();
        this.dataDevolucao = emprestimo.getDataDevolucao();
        this.status = emprestimo.getStatus();
        this.livroId = emprestimo.getLivro().getId();
        this.usuarioId = emprestimo.getUsuario().getId();
    }
}
