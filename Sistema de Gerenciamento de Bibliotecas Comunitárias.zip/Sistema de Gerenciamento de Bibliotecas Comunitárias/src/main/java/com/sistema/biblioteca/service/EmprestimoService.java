package com.sistema.biblioteca.service;

import com.sistema.biblioteca.Dto.Request.EmprestimoRequestDTO;
import com.sistema.biblioteca.Dto.Response.EmprestimoResponseDTO;

import java.util.List;

public interface EmprestimoService {
    // Interface para o serviço de Emprestimo

    EmprestimoResponseDTO findById(Long id); // Método para encontrar um empréstimo por ID

    List<EmprestimoResponseDTO> findAll(); // Método para listar todos os empréstimos

    EmprestimoResponseDTO register(EmprestimoRequestDTO emprestimoDTO); // Método para registrar um novo empréstimo

    EmprestimoResponseDTO update(Long id, EmprestimoRequestDTO emprestimoDTO); // Método para atualizar um empréstimo existente

    String delete(Long id); // Método para deletar um empréstimo por ID
}
