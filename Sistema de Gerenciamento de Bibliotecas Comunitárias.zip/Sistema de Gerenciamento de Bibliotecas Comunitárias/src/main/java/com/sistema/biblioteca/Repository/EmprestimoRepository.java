package com.sistema.biblioteca.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sistema.biblioteca.Entities.Emprestimo;

@Repository // Indica que a interface é um repositório Spring
public interface EmprestimoRepository extends JpaRepository<Emprestimo, Long> {
    // Estende a interface JpaRepository, indicando que trata-se de um repositório para a entidade Emprestimo
    // O segundo parâmetro <Emprestimo, Long> indica que a entidade é Emprestimo e o tipo da chave primária é Long
}
