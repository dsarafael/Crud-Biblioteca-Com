package com.sistema.biblioteca.service;

import com.sistema.biblioteca.Dto.Request.EmprestimoRequestDTO;
import com.sistema.biblioteca.Dto.Response.EmprestimoResponseDTO;
import com.sistema.biblioteca.Entities.Emprestimo;
import com.sistema.biblioteca.Repository.EmprestimoRepository;
import com.sistema.biblioteca.Util.EmprestimoMapper;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service // Indica que a classe é um serviço Spring
@RequiredArgsConstructor // Cria um construtor com os campos final, injetando as dependências automaticamente
public class EmprestimoServiceImpl implements EmprestimoService {
    // Implementação do serviço de Emprestimo

    private final EmprestimoRepository emprestimoRepository; // Repositório para operações com o banco de dados
    private final EmprestimoMapper emprestimoMapper; // Mapper para conversão entre DTOs e entidades

    @Override
    public EmprestimoResponseDTO findById(Long id) {
        return emprestimoMapper.toEmprestimoDTO(returnEmprestimo(id));
        // Retorna um DTO de empréstimo correspondente ao ID fornecido
    }

    @Override
    public List<EmprestimoResponseDTO> findAll() {
        return emprestimoMapper.toEmprestimoDTOList(emprestimoRepository.findAll());
        // Retorna uma lista de DTOs de empréstimo correspondentes a todos os empréstimos no banco de dados
    }

    @Override
    public EmprestimoResponseDTO register(EmprestimoRequestDTO emprestimoDTO) {
        Emprestimo emprestimo = emprestimoMapper.toEmprestimo(emprestimoDTO);
        // Converte o DTO de empréstimo em uma entidade de empréstimo
        return emprestimoMapper.toEmprestimoDTO(emprestimoRepository.save(emprestimo));
        // Salva o empréstimo no banco de dados e retorna o DTO correspondente ao empréstimo salvo
    }

    @Override
    public EmprestimoResponseDTO update(Long id, EmprestimoRequestDTO emprestimoDTO) {
        Emprestimo emprestimo = returnEmprestimo(id);
        // Encontra o empréstimo pelo ID fornecido
        emprestimoMapper.updateEmprestimoData(emprestimo, emprestimoDTO);
        // Atualiza os dados do empréstimo com base no DTO fornecido
        return emprestimoMapper.toEmprestimoDTO(emprestimoRepository.save(emprestimo));
        // Salva as alterações no empréstimo e retorna o DTO correspondente ao empréstimo atualizado
    }

    @Override
    public String delete(Long id) {
        emprestimoRepository.deleteById(id);
        // Deleta o empréstimo pelo ID fornecido
        return "Empréstimo id: " + id + " deleted";
        // Retorna uma mensagem indicando que o empréstimo foi deletado com sucesso
    }

    private Emprestimo returnEmprestimo(Long id) {
        return emprestimoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Empréstimo não encontrado no banco de dados"));
        // Encontra o empréstimo pelo ID fornecido no banco de dados ou lança uma exceção se não encontrar
    }
}
