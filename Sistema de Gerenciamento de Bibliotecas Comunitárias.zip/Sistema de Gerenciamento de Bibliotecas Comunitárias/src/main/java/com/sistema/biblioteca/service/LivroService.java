package com.sistema.biblioteca.service;

import java.util.List;

import com.sistema.biblioteca.Dto.Request.LivroRequestDTO;
import com.sistema.biblioteca.Dto.Response.LivroResponseDTO;

public interface LivroService {
    // Interface para o serviço de Livro

    LivroResponseDTO findById(Long Id); // Método para encontrar um livro por ID

    List<LivroResponseDTO> findAll(); // Método para listar todos os livros

    LivroResponseDTO register(LivroRequestDTO livroDTO); // Método para registrar um novo livro

    LivroResponseDTO update(Long id, LivroRequestDTO livroDTO); // Método para atualizar um livro existente

    String delete(Long id); // Método para deletar um livro por ID
}
