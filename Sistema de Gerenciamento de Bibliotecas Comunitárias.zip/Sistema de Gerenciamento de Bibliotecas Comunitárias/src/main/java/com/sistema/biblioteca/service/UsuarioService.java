package com.sistema.biblioteca.service;

import com.sistema.biblioteca.Dto.Request.UsuarioRequestDTO;
import com.sistema.biblioteca.Dto.Response.UsuarioResponseDTO;

import java.util.List;

public interface UsuarioService {
    // Interface que define os métodos disponíveis para manipulação de Usuários

    UsuarioResponseDTO findById(Long id); // Método para encontrar um Usuário pelo ID e retornar suas informações

    List<UsuarioResponseDTO> findAll(); // Método para encontrar todos os Usuários e retornar uma lista de suas informações

    UsuarioResponseDTO register(UsuarioRequestDTO usuarioDTO); // Método para registrar um novo Usuário com base nas informações fornecidas

    UsuarioResponseDTO update(Long id, UsuarioRequestDTO usuarioDTO); // Método para atualizar as informações de um Usuário existente com base no ID fornecido

    String delete(Long id); // Método para deletar um Usuário com base no ID fornecido e retornar uma mensagem indicando a exclusão
}
