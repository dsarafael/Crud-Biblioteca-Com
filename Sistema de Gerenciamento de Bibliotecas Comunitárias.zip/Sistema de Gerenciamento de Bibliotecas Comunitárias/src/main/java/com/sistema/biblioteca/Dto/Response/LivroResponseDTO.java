package com.sistema.biblioteca.Dto.Response;

import java.util.Date;

import com.sistema.biblioteca.Entities.Livro;

import lombok.Getter;

@Getter
public class LivroResponseDTO {
    // DTO para enviar dados de resposta de livro

    private Long id;                // ID do livro
    private String titulo;          // Título do livro
    private String categoria;       // Categoria do livro
    private int ano_publicacao;     // Ano de publicação do livro
    private String status;          // Status do livro
    private Date data_aquisicao;    // Data de aquisição do livro
    private String autor;           // Autor do livro

    // Construtor que recebe um objeto de livro e popula os campos do DTO
    public LivroResponseDTO(Livro livro) {
        this.id = livro.getId();
        this.titulo = livro.getTitulo();
        this.categoria = livro.getCategoria();
        this.ano_publicacao = livro.getAno_publicacao();
        this.status = livro.getStatus();
        this.data_aquisicao = livro.getData_aquisicao();
        this.autor = livro.getAutor();
    }
}
