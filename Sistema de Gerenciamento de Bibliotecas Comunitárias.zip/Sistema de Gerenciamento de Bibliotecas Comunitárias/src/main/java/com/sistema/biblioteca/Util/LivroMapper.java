package com.sistema.biblioteca.Util;

import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import java.util.List;

import com.sistema.biblioteca.Entities.Livro;
import com.sistema.biblioteca.Dto.Request.LivroRequestDTO;
import com.sistema.biblioteca.Dto.Response.LivroResponseDTO;

@Component
public class LivroMapper {
    // Mapper para converter entre DTOs e a entidade Livro

    public Livro toLivro(LivroRequestDTO livroDTO) {
        // Método para converter um DTO de Livro em uma entidade Livro
        Livro livro = Livro.builder()
                .titulo(livroDTO.getTitulo())
                .categoria(livroDTO.getCategoria())
                .ano_publicacao(livroDTO.getAno_publicacao())
                .status(livroDTO.getStatus())
                .data_aquisicao(livroDTO.getData_aquisicao())
                .autor(livroDTO.getAutor())
                .build();

        return livro;
    }

    public LivroResponseDTO toLivroDTO(Livro livro) {
        // Método para converter uma entidade Livro em um DTO de Livro
        return new LivroResponseDTO(livro);
    }

    public List<LivroResponseDTO> toExemplarDTO(List<Livro> livroList) {
        // Método para converter uma lista de entidades Livro em uma lista de DTOs de Livro
        return livroList.stream().map(LivroResponseDTO::new).collect((Collectors.toList()));
    }

    public void updateLivroData(Livro livro, LivroRequestDTO livroDTO) {
        // Método para atualizar os dados de um Livro com base nas informações fornecidas no DTO
        livro.setTitulo(livroDTO.getTitulo());
        livro.setCategoria(livroDTO.getCategoria());
        livro.setAno_publicacao(livroDTO.getAno_publicacao());
        livro.setStatus(livroDTO.getStatus());
        livro.setData_aquisicao(livroDTO.getData_aquisicao());
        livro.setAutor(livroDTO.getAutor());
    }
}
