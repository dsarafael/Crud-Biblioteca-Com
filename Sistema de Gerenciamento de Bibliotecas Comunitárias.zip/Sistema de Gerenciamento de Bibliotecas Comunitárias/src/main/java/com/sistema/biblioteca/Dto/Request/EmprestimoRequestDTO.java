package com.sistema.biblioteca.Dto.Request;

import lombok.Getter;

import java.util.Date;

@Getter
public class EmprestimoRequestDTO {
    // DTO para receber dados de solicitação de empréstimo

    private Date dataEmprestimo; // Data de empréstimo solicitada
    private Date dataDevolucao;  // Data de devolução solicitada
    private String status;       // Status da solicitação
    private Long livroId;        // ID do livro solicitado para empréstimo
    private Long usuarioId;      // ID do usuário que solicita o empréstimo
}
