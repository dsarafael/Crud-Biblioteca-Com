package com.sistema.biblioteca.Controllers;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import com.sistema.biblioteca.Dto.Request.LivroRequestDTO;
import com.sistema.biblioteca.Dto.Response.LivroResponseDTO;
import com.sistema.biblioteca.service.LivroService;

import lombok.RequiredArgsConstructor;

import java.net.URI;
import java.util.List;

import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping(value = "/livro")
@RequiredArgsConstructor
public class LivroController {
    // Controlador para operações relacionadas a livros

    private final LivroService livroService;

    // Endpoint para buscar um livro por ID
    @GetMapping(value = "/{id}")
    public ResponseEntity<LivroResponseDTO> findById(@PathVariable(name = "id") Long id) {
        return ResponseEntity.ok().body(livroService.findById(id));
    }

    // Endpoint para buscar todos os livros
    @GetMapping
    public ResponseEntity<List<LivroResponseDTO>> findAll() {
        return ResponseEntity.ok().body(livroService.findAll());
    }

    // Endpoint para registrar um novo livro
    @PostMapping
    public ResponseEntity<LivroResponseDTO> register(@RequestBody LivroRequestDTO livroRequestDTO, UriComponentsBuilder uriBuilder) {
        LivroResponseDTO livroResponseDTO = livroService.register(livroRequestDTO);
        URI uri = uriBuilder.path("/exemplar/{id}").buildAndExpand(livroResponseDTO.getId()).toUri();
        return ResponseEntity.created(uri).body(livroResponseDTO);
    }

    // Endpoint para atualizar um livro existente
    @PutMapping(value = "/{id}")
    public ResponseEntity<LivroResponseDTO> update(@RequestBody LivroRequestDTO livroDTO, @PathVariable(name = "id") Long id) {
        return ResponseEntity.ok().body(livroService.update(id, livroDTO));
    }

    // Endpoint para excluir um livro por ID
    @DeleteMapping(value = "/{id}")
    public ResponseEntity<String> delete(@PathVariable(value = "id") Long id) {
        return ResponseEntity.ok().body(livroService.delete(id));
    }
}
