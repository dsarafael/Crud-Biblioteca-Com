package com.sistema.biblioteca.service;

import java.util.List;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.sistema.biblioteca.Dto.Request.LivroRequestDTO;
import com.sistema.biblioteca.Dto.Response.LivroResponseDTO;
import com.sistema.biblioteca.Entities.Livro;
import com.sistema.biblioteca.Repository.LivroRepository;
import com.sistema.biblioteca.Util.LivroMapper;

import lombok.RequiredArgsConstructor;

@Service
@Primary
@RequiredArgsConstructor
public class LivroServiceImp implements LivroService {
    // Implementação do serviço de Livro

    private final LivroRepository livroRepository; // Repositório de Livro
    private final LivroMapper livroMapper; // Mapper para transformar LivroRequestDTO e LivroResponseDTO em Livro e vice-versa

    @Override
    public LivroResponseDTO findById(Long id) { 
        return livroMapper.toLivroDTO(returnLivro(id)); // Converte o Livro retornado pelo repositório para LivroResponseDTO

    }

    @Override
    public List<LivroResponseDTO> findAll() {
        return livroMapper.toExemplarDTO(livroRepository.findAll()); // Converte a lista de Livros retornada pelo repositório para uma lista de LivroResponseDTO

    }

    @Override
    public LivroResponseDTO register(LivroRequestDTO livroDTO) {
        Livro livro = livroMapper.toLivro(livroDTO); // Converte o LivroRequestDTO para Livro
        return livroMapper.toLivroDTO(livroRepository.save(livro)); // Salva o Livro no repositório e converte o resultado para LivroResponseDTO
    }

    @Override
    public LivroResponseDTO update(Long id, LivroRequestDTO livroDTO) {
        Livro livro = returnLivro(id); // Encontra o Livro pelo ID
        livroMapper.updateLivroData(livro, livroDTO); // Atualiza os dados do Livro com base no LivroRequestDTO
        return livroMapper.toLivroDTO(livroRepository.save(livro)); // Salva o Livro atualizado no repositório e converte o resultado para LivroResponseDTO
    }

    @Override
    public String delete(Long id) {
        livroRepository.deleteById(id); // Deleta o Livro pelo ID
        return "Livro id: "+id+" deleted"; // Retorna uma mensagem indicando que o Livro foi deletado
    }
    
    private Livro returnLivro(Long id) {
        return livroRepository.findById(id)
        .orElseThrow(()-> new RuntimeException("Livro não encontrado no BANCO de DADOS")); // Retorna o Livro encontrado pelo ID ou lança uma exceção caso não seja encontrado
    }
}
