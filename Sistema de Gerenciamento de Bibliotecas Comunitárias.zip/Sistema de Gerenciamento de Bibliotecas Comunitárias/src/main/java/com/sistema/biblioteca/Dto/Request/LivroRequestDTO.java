package com.sistema.biblioteca.Dto.Request;

import java.util.Date;

import lombok.Getter;

@Getter
public class LivroRequestDTO {
    // DTO para receber dados de requisição de livro

    private String titulo;           // Título do livro
    private String categoria;        // Categoria do livro
    private int ano_publicacao;      // Ano de publicação do livro
    private String status;           // Status do livro
    private Date data_aquisicao;     // Data de aquisição do livro
    private String autor;            // Autor do livro
}
