package com.sistema.biblioteca.Entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity // Indica que a classe é uma entidade JPA
@Table(name = "tb_emprestimo") // Mapeia a classe para a tabela "tb_emprestimo" no banco de dados
@NoArgsConstructor // Gera um construtor sem argumentos
@Getter // Gera métodos getter
@Setter // Gera métodos setter
public class Emprestimo {

    @Id // Indica que o campo é uma chave primária
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Gera automaticamente o valor do campo
    @Column(name = "id", nullable = false, unique = true) // Mapeia a coluna "id" no banco de dados
    @Setter(AccessLevel.NONE) // Impede a geração do setter para o campo "id"
    private Long id;

    @Column(name = "data_emprestimo", nullable = false) // Mapeia a coluna "data_emprestimo" no banco de dados
    private Date dataEmprestimo;

    @Column(name = "data_devolucao", nullable = false) // Mapeia a coluna "data_devolucao" no banco de dados
    private Date dataDevolucao;

    @Column(name = "status", nullable = false) // Mapeia a coluna "status" no banco de dados
    private String status;

    @ManyToOne // Mapeia a relação Many-to-One com a tabela "tb_livro"
    @JoinColumn(name = "fk_livro_id", nullable = false) // Define a chave estrangeira para a tabela "tb_livro"
    private Livro livro;

    @ManyToOne // Mapeia a relação Many-to-One com a tabela "tb_usuario"
    @JoinColumn(name = "fk_usuario_id", nullable = false) // Define a chave estrangeira para a tabela "tb_usuario"
    private Usuario usuario;

    @Builder // Gera um padrão Builder para a classe
    public Emprestimo(Date dataEmprestimo, Date dataDevolucao, String status, Livro livro, Usuario usuario) {
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataDevolucao;
        this.status = status;
        this.livro = livro;
        this.usuario = usuario;
    }
}
