package com.sistema.biblioteca.Controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import com.sistema.biblioteca.Dto.Request.UsuarioRequestDTO;
import com.sistema.biblioteca.Dto.Response.UsuarioResponseDTO;
import com.sistema.biblioteca.service.UsuarioService;

import lombok.RequiredArgsConstructor;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping(value = "/usuario")
@RequiredArgsConstructor
public class UsuarioController {
    // Controlador para operações relacionadas a usuários

    private final UsuarioService usuarioService;

    // Endpoint para buscar um usuário por ID
    @GetMapping(value = "/{id}")
    public ResponseEntity<UsuarioResponseDTO> findById(@PathVariable(name = "id") Long id) {
        return ResponseEntity.ok().body(usuarioService.findById(id));
    }

    // Endpoint para buscar todos os usuários
    @GetMapping
    public ResponseEntity<List<UsuarioResponseDTO>> findAll() {
        return ResponseEntity.ok().body(usuarioService.findAll());
    }

    // Endpoint para registrar um novo usuário
    @PostMapping
    public ResponseEntity<UsuarioResponseDTO> register(@RequestBody UsuarioRequestDTO usuarioRequestDTO, UriComponentsBuilder uriBuilder) {
        UsuarioResponseDTO usuarioResponseDTO = usuarioService.register(usuarioRequestDTO);
        URI uri = uriBuilder.path("/usuario/{id}").buildAndExpand(usuarioResponseDTO.getId()).toUri();
        return ResponseEntity.created(uri).body(usuarioResponseDTO);
    }

    // Endpoint para atualizar um usuário existente
    @PutMapping(value = "/{id}")
    public ResponseEntity<UsuarioResponseDTO> update(@RequestBody UsuarioRequestDTO usuarioDTO, @PathVariable(name = "id") Long id) {
        return ResponseEntity.ok().body(usuarioService.update(id, usuarioDTO));
    }

    // Endpoint para excluir um usuário por ID
    @DeleteMapping(value = "/{id}")
    public ResponseEntity<String> delete(@PathVariable(value = "id") Long id) {
        return ResponseEntity.ok().body(usuarioService.delete(id));
    }
}
