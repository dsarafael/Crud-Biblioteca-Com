package com.sistema.biblioteca.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sistema.biblioteca.Entities.Livro;

@Repository // Indica que a interface é um repositório Spring
public interface LivroRepository extends JpaRepository<Livro, Long> {
    // Estende a interface JpaRepository, indicando que trata-se de um repositório para a entidade Livro
    // O segundo parâmetro <Livro, Long> indica que a entidade é Livro e o tipo da chave primária é Long
}
