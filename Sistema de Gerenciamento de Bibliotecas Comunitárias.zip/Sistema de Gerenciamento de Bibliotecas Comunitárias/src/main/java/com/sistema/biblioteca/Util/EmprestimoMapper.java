package com.sistema.biblioteca.Util;

import com.sistema.biblioteca.Dto.Request.EmprestimoRequestDTO;
import com.sistema.biblioteca.Dto.Response.EmprestimoResponseDTO;
import com.sistema.biblioteca.Entities.Emprestimo;
import com.sistema.biblioteca.Entities.Livro;
import com.sistema.biblioteca.Entities.Usuario;
import com.sistema.biblioteca.Repository.LivroRepository;
import com.sistema.biblioteca.Repository.UsuarioRepository;

import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class EmprestimoMapper {
    // Mapper para converter entre DTOs e entidades relacionadas a empréstimos

    private final LivroRepository livroRepository;
    private final UsuarioRepository usuarioRepository;

    public EmprestimoMapper(LivroRepository livroRepository, UsuarioRepository usuarioRepository) {
        this.livroRepository = livroRepository;
        this.usuarioRepository = usuarioRepository;
    }

    public Emprestimo toEmprestimo(EmprestimoRequestDTO emprestimoDTO) {
        // Método para converter um DTO de empréstimo em uma entidade de empréstimo
        Livro livro = livroRepository.findById(emprestimoDTO.getLivroId())
                .orElseThrow(() -> new RuntimeException("Livro não encontrado no banco de dados"));
        Usuario usuario = usuarioRepository.findById(emprestimoDTO.getUsuarioId())
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado no banco de dados"));

        return Emprestimo.builder()
                .dataEmprestimo(emprestimoDTO.getDataEmprestimo())
                .dataDevolucao(emprestimoDTO.getDataDevolucao())
                .status(emprestimoDTO.getStatus())
                .livro(livro)
                .usuario(usuario)
                .build();
    }

    public EmprestimoResponseDTO toEmprestimoDTO(Emprestimo emprestimo) {
        // Método para converter uma entidade de empréstimo em um DTO de empréstimo
        return new EmprestimoResponseDTO(emprestimo);
    }

    public List<EmprestimoResponseDTO> toEmprestimoDTOList(List<Emprestimo> emprestimoList) {
        // Método para converter uma lista de entidades de empréstimo em uma lista de DTOs de empréstimo
        return emprestimoList.stream().map(EmprestimoResponseDTO::new).collect(Collectors.toList());
    }

    public void updateEmprestimoData(Emprestimo emprestimo, EmprestimoRequestDTO emprestimoDTO) {
        // Método para atualizar os dados de um empréstimo com base nas informações fornecidas no DTO
        emprestimo.setDataEmprestimo(emprestimoDTO.getDataEmprestimo());
        emprestimo.setDataDevolucao(emprestimoDTO.getDataDevolucao());
        emprestimo.setStatus(emprestimoDTO.getStatus());

        Livro livro = livroRepository.findById(emprestimoDTO.getLivroId())
                .orElseThrow(() -> new RuntimeException("Livro não encontrado no banco de dados"));
        Usuario usuario = usuarioRepository.findById(emprestimoDTO.getUsuarioId())
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado no banco de dados"));

        emprestimo.setLivro(livro);
        emprestimo.setUsuario(usuario);
    }
}
