package com.sistema.biblioteca.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sistema.biblioteca.Entities.Usuario;

@Repository // Indica que a interface é um repositório Spring
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    // Estende a interface JpaRepository, indicando que trata-se de um repositório para a entidade Usuario
    // O segundo parâmetro <Usuario, Long> indica que a entidade é Usuario e o tipo da chave primária é Long
}
