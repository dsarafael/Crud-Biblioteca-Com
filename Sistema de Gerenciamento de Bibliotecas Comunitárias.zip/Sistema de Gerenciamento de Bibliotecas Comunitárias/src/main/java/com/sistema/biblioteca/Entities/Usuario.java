package com.sistema.biblioteca.Entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity // Indica que a classe é uma entidade JPA
@Table(name = "tb_usuario") // Mapeia a classe para a tabela "tb_usuario" no banco de dados
@NoArgsConstructor // Gera um construtor sem argumentos
@Getter // Gera métodos getter
@Setter // Gera métodos setter
public class Usuario {

    @Id // Indica que o campo é uma chave primária
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Gera automaticamente o valor do campo
    @Column(name = "id", nullable = false, unique = true) // Mapeia a coluna "id" no banco de dados
    @Setter(AccessLevel.NONE) // Impede a geração do setter para o campo "id"
    private Long id;

    @Column(name = "nome", nullable = false) // Mapeia a coluna "nome" no banco de dados
    private String nome;

    @Column(name = "email", nullable = false) // Mapeia a coluna "email" no banco de dados
    private String email;

    @Column(name = "telefone", nullable = false) // Mapeia a coluna "telefone" no banco de dados
    private String telefone;

    @Column(name = "endereco", nullable = false) // Mapeia a coluna "endereco" no banco de dados
    private String endereco;

    @Builder // Gera um padrão Builder para a classe
    public Usuario(String nome, String email, String telefone, String endereco) {
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
        this.endereco = endereco;
    }
}
